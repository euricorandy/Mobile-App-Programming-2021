package com.hanson.android.recipe.Model;

public class IngredientItem {

    private String nameIngredient;

    public IngredientItem(String nameIngredient){
        this.nameIngredient= nameIngredient;
    }

    public String getNameIngredient(){
        return  this.nameIngredient;
    }
}
