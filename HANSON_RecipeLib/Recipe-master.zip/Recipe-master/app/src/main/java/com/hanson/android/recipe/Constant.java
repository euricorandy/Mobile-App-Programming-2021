package com.hanson.android.recipe;

public class Constant {
    public static final String ROOT_URL = "http://localhost/RecepieLib/v1/registerUser.php";
}
